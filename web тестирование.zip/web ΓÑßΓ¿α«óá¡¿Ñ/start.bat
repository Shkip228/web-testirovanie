@echo off
chcp 65001 >nul
echo ========================================
echo   Запуск сервера отчётов работников
echo ========================================
echo.

REM Проверяем Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [!] Python не установлен.
    echo [!] Скачайте с https://python.org
    echo [!] При установке отметьте "Add Python to PATH"
    pause
    exit /b
)

echo [*] Python найден:
python --version
echo.

REM Создаём папку templates если её нет
if not exist "templates" (
    echo [!] Создаю папку templates...
    mkdir templates
    echo [!] Поместите в неё файл index.html
    pause
    exit /b
)

echo [*] Запуск сервера на порту 5000...
echo [*] Откройте в браузере: http://127.0.0.1:5000
echo [*] Для остановки: Ctrl+C
echo.

python server.py
pause