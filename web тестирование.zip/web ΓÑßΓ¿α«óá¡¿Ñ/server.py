#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Сервер проверки отчётов работников
Работает на чистом Python без внешних библиотек
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import sqlite3
import json
import os
from datetime import datetime
from urllib.parse import urlparse, parse_qs

DB_PATH = 'reports.db'
TEMPLATES_DIR = 'templates'
PORT = 5000

# ============ РАБОТА С БД ============
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Создание таблиц при первом запуске"""
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS workers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            position TEXT,
            department TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER NOT NULL,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            score INTEGER DEFAULT 0,
            comment TEXT,
            checked_by TEXT,
            checked_at TEXT,
            UNIQUE(worker_id, year, month),
            FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
        )
    ''')
    conn.commit()
    conn.close()

# ============ HTTP ОБРАБОТЧИК ============
class ReportsHandler(BaseHTTPRequestHandler):
    
    def log_message(self, format, *args):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {args[0]}")
    
    def send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))
    
    def send_html(self, html_content):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html_content.encode('utf-8'))
    
    def read_json_body(self):
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length == 0:
            return {}
        body = self.rfile.read(content_length)
        return json.loads(body.decode('utf-8'))
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        
        # Главная страница
        if path == '/':
            try:
                with open(os.path.join(TEMPLATES_DIR, 'index.html'), 'r', encoding='utf-8') as f:
                    self.send_html(f.read())
            except FileNotFoundError:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b'index.html not found in templates/')
            return
        
        # Проверка работоспособности
        elif path == '/api/health':
            self.send_json({
                'status': 'ok',
                'time': datetime.now().isoformat(),
                'db': os.path.exists(DB_PATH)
            })
        
        # API: список работников
        elif path == '/api/workers':
            conn = get_db()
            workers = conn.execute('SELECT * FROM workers ORDER BY name').fetchall()
            conn.close()
            self.send_json([dict(w) for w in workers])
        
        # API: отчёты работника
        elif path.startswith('/api/reports/'):
            try:
                worker_id = int(path.split('/')[-1])
                year = int(query.get('year', [datetime.now().year])[0])
                
                conn = get_db()
                reports = conn.execute(
                    'SELECT * FROM reports WHERE worker_id = ? AND year = ?',
                    (worker_id, year)
                ).fetchall()
                conn.close()
                
                result = {r['month']: dict(r) for r in reports}
                self.send_json(result)
            except (ValueError, IndexError):
                self.send_json({'error': 'Invalid request'}, 400)
        
        # API: статистика
        elif path == '/api/stats':
            year = int(query.get('year', [datetime.now().year])[0])
            conn = get_db()
            
            workers_count = conn.execute('SELECT COUNT(*) FROM workers').fetchone()[0]
            
            stats = {
                'workers_count': workers_count,
                'passed': 0, 'partial': 0, 'failed': 0, 'pending': 0,
                'total_score': 0, 'scored_count': 0,
                'by_worker': {}
            }
            
            workers = conn.execute('SELECT id, name FROM workers').fetchall()
            for w in workers:
                reports = conn.execute(
                    'SELECT * FROM reports WHERE worker_id = ? AND year = ?',
                    (w['id'], year)
                ).fetchall()
                
                worker_stats = {
                    'passed': 0, 'partial': 0, 'failed': 0, 
                    'pending': 0, 'months': {}, 'total_score': 0, 'scored_count': 0
                }
                
                for m in range(12):
                    r = next((x for x in reports if x['month'] == m), None)
                    if r:
                        worker_stats['months'][m] = dict(r)
                        worker_stats[r['status']] = worker_stats.get(r['status'], 0) + 1
                        stats[r['status']] += 1
                        if r['score'] > 0:
                            worker_stats['total_score'] += r['score']
                            worker_stats['scored_count'] += 1
                            stats['total_score'] += r['score']
                            stats['scored_count'] += 1
                    else:
                        worker_stats['months'][m] = None
                        worker_stats['pending'] += 1
                        stats['pending'] += 1
                
                worker_stats['avg'] = (
                    worker_stats['total_score'] / worker_stats['scored_count']
                    if worker_stats['scored_count'] > 0 else None
                )
                stats['by_worker'][w['id']] = {
                    'name': w['name'],
                    'stats': worker_stats
                }
            
            conn.close()
            
            stats['avg'] = (
                stats['total_score'] / stats['scored_count']
                if stats['scored_count'] > 0 else None
            )
            checked = stats['passed'] + stats['partial'] + stats['failed']
            stats['pass_rate'] = (stats['passed'] / checked * 100) if checked > 0 else None
            
            self.send_json(stats)
        
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        # API: добавить работника
        if path == '/api/workers':
            try:
                data = self.read_json_body()
                if not data.get('name'):
                    self.send_json({'error': 'ФИО обязательно'}, 400)
                    return
                
                conn = get_db()
                c = conn.cursor()
                c.execute(
                    'INSERT INTO workers (name, position, department) VALUES (?, ?, ?)',
                    (data['name'], data.get('position', ''), data.get('department', ''))
                )
                conn.commit()
                new_id = c.lastrowid
                worker = conn.execute('SELECT * FROM workers WHERE id = ?', (new_id,)).fetchone()
                conn.close()
                self.send_json(dict(worker), 201)
            except Exception as e:
                self.send_json({'error': str(e)}, 500)
        
        # API: сохранить отчёт
        elif path == '/api/reports':
            try:
                data = self.read_json_body()
                required = ['worker_id', 'year', 'month', 'status']
                if not all(k in data for k in required):
                    self.send_json({'error': 'Не все поля заполнены'}, 400)
                    return
                
                conn = get_db()
                conn.execute('''
                    INSERT INTO reports (worker_id, year, month, status, score, comment, checked_by, checked_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(worker_id, year, month) DO UPDATE SET
                        status = excluded.status,
                        score = excluded.score,
                        comment = excluded.comment,
                        checked_by = excluded.checked_by,
                        checked_at = excluded.checked_at
                ''', (
                    data['worker_id'], data['year'], data['month'],
                    data['status'], data.get('score', 0), data.get('comment', ''),
                    data.get('checked_by', 'admin'),
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                ))
                conn.commit()
                conn.close()
                self.send_json({'ok': True})
            except Exception as e:
                self.send_json({'error': str(e)}, 500)
        
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path.startswith('/api/workers/'):
            try:
                worker_id = int(path.split('/')[-1])
                conn = get_db()
                conn.execute('DELETE FROM workers WHERE id = ?', (worker_id,))
                conn.execute('DELETE FROM reports WHERE worker_id = ?', (worker_id,))
                conn.commit()
                conn.close()
                self.send_json({'ok': True})
            except (ValueError, IndexError):
                self.send_json({'error': 'Invalid request'}, 400)
        else:
            self.send_response(404)
            self.end_headers()

# ============ ЗАПУСК ============
if __name__ == '__main__':
    # Создаём папку templates если её нет
    if not os.path.exists(TEMPLATES_DIR):
        os.makedirs(TEMPLATES_DIR)
        print(f"[!] Создана папка {TEMPLATES_DIR}. Поместите туда index.html")
    
    init_db()
    
    server = HTTPServer(('0.0.0.0', PORT), ReportsHandler)
    
    print("=" * 55)
    print("  🚀 СЕРВЕР ОТЧЁТОВ РАБОТНИКОВ ЗАПУЩЕН")
    print("=" * 55)
    print(f"  📍 Локально:   http://10.90.14.157:{PORT}")
    print(f"  💾 База данных: {DB_PATH}")
    print(f"  📁 Папка:      {os.path.abspath('.')}")
    print("=" * 55)
    print("  Для остановки нажмите Ctrl+C")
    print("=" * 55)
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Сервер остановлен")
        server.server_close()